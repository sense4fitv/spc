<?php

namespace App\Services;

use App\Models\TaskModel;
use App\Models\UserModel;
use App\Models\ContractModel;
use App\Models\SubdivisionModel;
use App\Models\RegionModel;

/**
 * TaskManagementService
 * 
 * Service responsible for task management business logic,
 * including permission checks and data filtering based on user roles.
 */
class TaskManagementService
{
    protected TaskModel $taskModel;
    protected UserModel $userModel;
    protected ContractModel $contractModel;
    protected SubdivisionModel $subdivisionModel;
    protected RegionModel $regionModel;

    /**
     * Role level mappings
     */
    protected array $roleLevels = [
        'admin'      => 100,
        'director'   => 80,
        'manager'    => 50,
        'executant'  => 20,
        'auditor'    => 10,
    ];

    public function __construct()
    {
        $this->taskModel = new TaskModel();
        $this->userModel = new UserModel();
        $this->contractModel = new ContractModel();
        $this->subdivisionModel = new SubdivisionModel();
        $this->regionModel = new RegionModel();
    }

    /**
     * Get viewable tasks based on current user's role
     * 
     * @param int $currentUserId Current user ID
     * @return array Array of tasks with additional data
     */
    public function getViewableTasks(int $currentUserId): array
    {
        $currentUser = $this->userModel->find($currentUserId);

        if (!$currentUser) {
            return [];
        }

        $roleLevel = $currentUser['role_level'];

        // Admin sees all tasks
        if ($roleLevel >= $this->roleLevels['admin']) {
            return $this->taskModel->getAllTasksWithDetails();
        }

        // Director sees tasks from contracts in his region (region_id is required)
        if ($roleLevel >= $this->roleLevels['director']) {
            $regionId = $currentUser['region_id'];
            if (!$regionId) {
                // Director must have region_id - if missing, return empty
                return [];
            }
            return $this->taskModel->getTasksForRegionWithDetails($regionId);
        }

        // Manager sees only tasks from contracts assigned to him
        if ($roleLevel >= $this->roleLevels['manager']) {
            return $this->taskModel->getTasksForManagerWithDetails($currentUserId);
        }

        // Executant sees only tasks assigned to him
        if ($roleLevel >= $this->roleLevels['executant']) {
            return $this->taskModel->getTasksForAssigneeWithDetails($currentUserId);
        }

        // Auditor - no access to tasks
        return [];
    }

    /**
     * Get tasks assigned to or created by a user (for "My Tasks" view)
     * 
     * @param int $currentUserId Current user ID
     * @return array Array of tasks with additional data
     */
    public function getMyTasks(int $currentUserId): array
    {
        $currentUser = $this->userModel->find($currentUserId);

        if (!$currentUser) {
            return [];
        }

        // Get tasks where user is assignee OR creator
        $tasks = $this->taskModel->getMyTasksWithDetails($currentUserId);

        return $tasks;
    }

    /**
     * Check if current user can create a task for a subdivision
     * 
     * @param int $currentUserId Current user ID
     * @param int $subdivisionId Subdivision ID
     * @return bool
     */
    public function canCreateTask(int $currentUserId, int $subdivisionId): bool
    {
        $currentUser = $this->userModel->find($currentUserId);
        $subdivision = $this->subdivisionModel->find($subdivisionId);

        if (!$currentUser || !$subdivision) {
            return false;
        }

        $roleLevel = $currentUser['role_level'];

        // Executant cannot create tasks
        if ($roleLevel < $this->roleLevels['manager']) {
            return false;
        }

        // Get the contract for this subdivision
        $contract = $this->contractModel->find($subdivision['contract_id']);
        if (!$contract) {
            return false;
        }

        // Admin can create anywhere
        if ($roleLevel >= $this->roleLevels['admin']) {
            return true;
        }

        // Director can create only in contracts from his region (region_id is required)
        if ($roleLevel >= $this->roleLevels['director']) {
            $directorRegionId = $currentUser['region_id'];
            if (!$directorRegionId) {
                // Director must have region_id - cannot create without it
                return false;
            }
            return $contract['region_id'] == $directorRegionId;
        }

        // Manager can create only in contracts assigned to him
        if ($roleLevel >= $this->roleLevels['manager']) {
            return $contract['manager_id'] == $currentUserId;
        }

        return false;
    }

    /**
     * Check if current user can edit a task
     * 
     * @param int $currentUserId Current user ID
     * @param int $taskId Task ID to edit
     * @return bool
     */
    public function canEditTask(int $currentUserId, int $taskId): bool
    {
        $currentUser = $this->userModel->find($currentUserId);
        $task = $this->taskModel->find($taskId);

        if (!$currentUser || !$task) {
            return false;
        }

        $roleLevel = $currentUser['role_level'];

        // Executant cannot edit tasks (only view)
        if ($roleLevel < $this->roleLevels['manager']) {
            return false;
        }

        // Get the subdivision and contract for this task
        $subdivision = $this->subdivisionModel->find($task['subdivision_id']);
        if (!$subdivision) {
            return false;
        }

        $contract = $this->contractModel->find($subdivision['contract_id']);
        if (!$contract) {
            return false;
        }

        // Admin can edit any task
        if ($roleLevel >= $this->roleLevels['admin']) {
            return true;
        }

        // Director can edit only tasks from contracts in his region (region_id is required)
        if ($roleLevel >= $this->roleLevels['director']) {
            $directorRegionId = $currentUser['region_id'];
            if (!$directorRegionId) {
                // Director must have region_id - cannot edit without it
                return false;
            }
            return $contract['region_id'] == $directorRegionId;
        }

        // Manager can edit only tasks from contracts assigned to him
        if ($roleLevel >= $this->roleLevels['manager']) {
            return $contract['manager_id'] == $currentUserId;
        }

        return false;
    }

    /**
     * Check if current user can delete a task
     * 
     * @param int $currentUserId Current user ID
     * @param int $taskId Task ID to delete
     * @return bool
     */
    public function canDeleteTask(int $currentUserId, int $taskId): bool
    {
        // Same logic as edit
        return $this->canEditTask($currentUserId, $taskId);
    }

    /**
     * Check if current user can view a task
     * 
     * @param int $currentUserId Current user ID
     * @param int $taskId Task ID to view
     * @return bool
     */
    public function canViewTask(int $currentUserId, int $taskId): bool
    {
        $currentUser = $this->userModel->find($currentUserId);
        $task = $this->taskModel->find($taskId);

        if (!$currentUser || !$task) {
            return false;
        }

        $roleLevel = $currentUser['role_level'];

        // Admin can view any task
        if ($roleLevel >= $this->roleLevels['admin']) {
            return true;
        }

        // Executant can view only tasks assigned to him
        if ($roleLevel >= $this->roleLevels['executant'] && $roleLevel < $this->roleLevels['manager']) {
            // Check if user is assignee
            // getAssignees() returns users.* data, so use 'id' field
            $assignees = $this->taskModel->getAssignees($taskId);
            foreach ($assignees as $assignee) {
                if (isset($assignee['id']) && $assignee['id'] == $currentUserId) {
                    return true;
                }
            }
            // Or if user is creator
            return $task['created_by'] == $currentUserId;
        }

        // For managers and directors, check based on contract permissions
        $subdivision = $this->subdivisionModel->find($task['subdivision_id']);
        if (!$subdivision) {
            return false;
        }

        $contract = $this->contractModel->find($subdivision['contract_id']);
        if (!$contract) {
            return false;
        }

        // Director can view tasks from contracts in his region (region_id is required)
        if ($roleLevel >= $this->roleLevels['director']) {
            $directorRegionId = $currentUser['region_id'];
            if (!$directorRegionId) {
                // Director must have region_id - cannot view without it
                return false;
            }
            return $contract['region_id'] == $directorRegionId;
        }

        // Manager can view tasks from contracts assigned to him
        if ($roleLevel >= $this->roleLevels['manager']) {
            return $contract['manager_id'] == $currentUserId;
        }

        return false;
    }

    /**
     * Get allowed subdivisions for task creation
     * 
     * @param int $currentUserId Current user ID
     * @return array Array of subdivisions [id => name (with contract info)]
     */
    public function getAllowedSubdivisionsForCreate(int $currentUserId): array
    {
        $currentUser = $this->userModel->find($currentUserId);

        if (!$currentUser) {
            return [];
        }

        $roleLevel = $currentUser['role_level'];

        // Executant cannot create tasks
        if ($roleLevel < $this->roleLevels['manager']) {
            return [];
        }

        // Admin sees all subdivisions
        if ($roleLevel >= $this->roleLevels['admin']) {
            $subdivisions = $this->subdivisionModel->findAll();
            $result = [];
            foreach ($subdivisions as $subdivision) {
                $contract = $this->contractModel->find($subdivision['contract_id']);
                $contractName = $contract ? $contract['name'] : 'Necunoscut';
                $result[$subdivision['id']] = $subdivision['name'] . ' (' . $contractName . ')';
            }
            return $result;
        }

        // Director sees subdivisions from contracts in his region (region_id is required)
        if ($roleLevel >= $this->roleLevels['director']) {
            $regionId = $currentUser['region_id'];
            if (!$regionId) {
                // Director must have region_id - return empty if missing
                return [];
            }
            $subdivisions = $this->subdivisionModel->getSubdivisionsForRegionWithDetails($regionId);
            $result = [];
            foreach ($subdivisions as $subdivision) {
                $result[$subdivision['id']] = $subdivision['name'] . ' (' . $subdivision['contract_name'] . ')';
            }
            return $result;
        }

        // Manager sees subdivisions from contracts assigned to him
        if ($roleLevel >= $this->roleLevels['manager']) {
            $subdivisions = $this->subdivisionModel->getSubdivisionsForManagerWithDetails($currentUserId);
            $result = [];
            foreach ($subdivisions as $subdivision) {
                $result[$subdivision['id']] = $subdivision['name'] . ' (' . $subdivision['contract_name'] . ')';
            }
            return $result;
        }

        return [];
    }

    /**
     * Get all users that can be assigned to tasks
     * Based on current user's permissions, returns appropriate list
     * 
     * @param int $currentUserId Current user ID
     * @return array Array of users [id => full_name]
     */
    public function getAllowedUsersForAssignment(int $currentUserId): array
    {
        $currentUser = $this->userModel->find($currentUserId);

        if (!$currentUser) {
            return [];
        }

        $roleLevel = $currentUser['role_level'];

        // Admin can assign to anyone
        if ($roleLevel >= $this->roleLevels['admin']) {
            $users = $this->userModel->where('active', 1)->findAll();
            $result = [];
            foreach ($users as $user) {
                $fullName = trim(($user['first_name'] ?? '') . ' ' . ($user['last_name'] ?? ''));
                $result[$user['id']] = $fullName ?: $user['email'];
            }
            return $result;
        }

        // Director can assign to users in his region (region_id is required)
        if ($roleLevel >= $this->roleLevels['director']) {
            $regionId = $currentUser['region_id'];
            if (!$regionId) {
                // Director must have region_id - return empty if missing
                return [];
            }
            $users = $this->userModel->getUsersForDirector($currentUserId, $regionId);
            $result = [];
            foreach ($users as $user) {
                $fullName = trim(($user['first_name'] ?? '') . ' ' . ($user['last_name'] ?? ''));
                $result[$user['id']] = $fullName ?: $user['email'];
            }
            return $result;
        }

        // Manager can assign to users he manages
        if ($roleLevel >= $this->roleLevels['manager']) {
            $users = $this->userModel->getUsersForContractManager($currentUserId);
            $result = [];
            foreach ($users as $user) {
                $fullName = trim(($user['first_name'] ?? '') . ' ' . ($user['last_name'] ?? ''));
                $result[$user['id']] = $fullName ?: $user['email'];
            }
            return $result;
        }

        return [];
    }
}
