<?php

namespace App\Controllers;

use App\Services\NotificationService;
use App\Services\DashboardService;

class DashboardController extends BaseController
{
    protected DashboardService $dashboardService;
    protected NotificationService $notificationService;

    public function __construct()
    {
        $this->dashboardService = new DashboardService();
        $this->notificationService = new NotificationService();
    }

    /**
     * Main dashboard view (role-based)
     */
    public function index()
    {
        $session = service('session');
        $role = $session->get('role');
        $userId = $session->get('user_id');
        $roleLevel = $session->get('role_level');
        $regionId = $session->get('region_id');

        log_message('debug', "DashboardController::index - User ID: {$userId}, Role: {$role}, RoleLevel: {$roleLevel}, RegionID: {$regionId}");

        // AuthFilter already handles authentication - if we're here, user is authenticated
        // No need for redundant checks that could cause redirect loops

        // Get KPIs
        $kpis = $this->dashboardService->getKPIs($userId, $role, $regionId);

        // Get regions for drill-down (if applicable)
        $regions = $this->dashboardService->getRegionsForDashboard($userId, $role, $regionId);

        // Get chart data
        $chartData = $this->dashboardService->getTasksPerRegionChart($userId, $role, $regionId, '30days');

        // Get team workload (if applicable)
        $teamWorkload = [];
        if (in_array($role, ['admin', 'director', 'manager', 'auditor'])) {
            $teamWorkload = $this->dashboardService->getTeamWorkload($userId, $role, $regionId);
        }

        // Get critical blockers
        $criticalBlockers = $this->dashboardService->getCriticalBlockers($userId, $role, $regionId, 5);

        // Get upcoming deadlines
        $upcomingDeadlines = $this->dashboardService->getUpcomingDeadlines($userId, $role, $regionId, 5);

        // For executant, get personal tasks
        $personalTasks = [];
        if ($role === 'executant') {
            $taskModel = new \App\Models\TaskModel();
            $personalTasks = $taskModel->getMyTasksWithDetails($userId);
        }

        // For manager, get contracts directly (skip region level)
        $contracts = [];
        if ($role === 'manager' && $regionId) {
            $contracts = $this->dashboardService->getContractsForDashboard($userId, $role, $regionId);
        }

        $data = [
            'kpis' => $kpis,
            'regions' => $regions,
            'contracts' => $contracts,
            'chartData' => $chartData,
            'teamWorkload' => $teamWorkload,
            'criticalBlockers' => $criticalBlockers,
            'upcomingDeadlines' => $upcomingDeadlines,
            'personalTasks' => $personalTasks,
            'role' => $role,
            'userId' => $userId,
            'regionId' => $regionId,
        ];

        switch ($role) {
            case 'admin':
                return view('dashboard/admin', $data);
            case 'director':
                return view('dashboard/director', $data);
            case 'manager':
                return view('dashboard/manager', $data);
            case 'executant':
                return view('dashboard/executant', $data);
            case 'auditor':
                return view('dashboard/auditor', $data);
        }
    }

    /**
     * View region detail (drill-down)
     * GET /dashboard/region/{id}
     */
    public function regionView(int $id)
    {
        $session = service('session');
        $userId = $session->get('user_id');
        $role = $session->get('role');
        $roleLevel = $session->get('role_level');
        $userRegionId = $session->get('region_id');

        // Check permissions
        if ($role === 'manager' && $userRegionId !== $id) {
            return redirect()->to('/dashboard')->with('error', 'Nu ai permisiunea să accesezi această regiune.');
        }

        // Get region data
        $region = $this->dashboardService->getRegionData($id);

        if (!$region) {
            return redirect()->to('/dashboard')->with('error', 'Regiunea nu există.');
        }

        // Get contracts for this region
        // For admin, filter by region_id when viewing a specific region (drill-down)
        if ($role === 'admin') {
            $contractModel = new \App\Models\ContractModel();
            $contracts = $contractModel->getContractsForRegionWithDetails($id);
        } else {
            $contracts = $this->dashboardService->getContractsForDashboard($userId, $role, $id);
        }

        $data = [
            'region' => $region,
            'contracts' => $contracts,
        ];

        return view('dashboard/region', $data);
    }

    /**
     * View contract detail (drill-down)
     * GET /dashboard/contract/{id}
     */
    public function contractView(int $id)
    {
        $session = service('session');
        $userId = $session->get('user_id');
        $role = $session->get('role');
        $userRegionId = $session->get('region_id');

        // Get contract data
        $contract = $this->dashboardService->getContractData($id);

        if (!$contract) {
            return redirect()->to('/dashboard')->with('error', 'Contractul nu există.');
        }

        // Check permissions
        // Admin can view any contract (skip permission check)
        if ($role !== 'admin') {
            if ($role === 'manager') {
                // Manager can view only contracts assigned to him (via manager_id)
                if (!isset($contract['manager_id']) || $contract['manager_id'] != $userId) {
                    return redirect()->to('/dashboard')->with('error', 'Nu ai permisiunea să accesezi acest contract 1.');
                }
            } elseif ($role === 'director' && $userRegionId) {
                // Director can view only contracts from his region
                if (!isset($contract['region_id']) || $contract['region_id'] != $userRegionId) {
                    return redirect()->to('/dashboard')->with('error', 'Nu ai permisiunea să accesezi acest contract 2.');
                }
            } elseif ($role === 'director' && !$userRegionId) {
                // Director must have region_id
                return redirect()->to('/dashboard')->with('error', 'Nu ai permisiunea să accesezi acest contract 3.');
            }
        }

        // Get subdivisions for this contract
        $subdivisionModel = new \App\Models\SubdivisionModel();
        $subdivisions = $subdivisionModel->where('contract_id', $id)->findAll();

        // Add task counts
        foreach ($subdivisions as &$subdivision) {
            $tasks = $subdivisionModel->getTasks($subdivision['id']);
            $subdivision['tasks_count'] = count($tasks);
        }

        $data = [
            'contract' => $contract,
            'subdivisions' => $subdivisions,
        ];

        return view('dashboard/contract', $data);
    }

    /**
     * View subdivision detail (drill-down)
     * GET /dashboard/subdivision/{id}
     */
    public function subdivisionView(int $id)
    {
        $session = service('session');
        $userId = $session->get('user_id');
        $role = $session->get('role');
        $userRegionId = $session->get('region_id');

        // Get subdivision data
        $subdivision = $this->dashboardService->getSubdivisionData($id);

        if (!$subdivision) {
            return redirect()->to('/dashboard')->with('error', 'Subdiviziunea nu există.');
        }

        // Check permissions
        // Admin can view any subdivision (skip permission check)
        if ($role !== 'admin') {
            if ($role === 'manager') {
                // Manager can view only subdivisions from contracts assigned to him (via manager_id)
                if (!isset($subdivision['contract']['manager_id']) || $subdivision['contract']['manager_id'] != $userId) {
                    return redirect()->to('/dashboard')->with('error', 'Nu ai permisiunea să accesezi această subdiviziune.');
                }
            } elseif ($role === 'director' && $userRegionId) {
                // Director can view only subdivisions from contracts in his region
                if (!isset($subdivision['contract']['region_id']) || $subdivision['contract']['region_id'] != $userRegionId) {
                    return redirect()->to('/dashboard')->with('error', 'Nu ai permisiunea să accesezi această subdiviziune.');
                }
            } elseif ($role === 'director' && !$userRegionId) {
                // Director must have region_id
                return redirect()->to('/dashboard')->with('error', 'Nu ai permisiunea să accesezi această subdiviziune.');
            }
        }

        // Get tasks from subdivision data (already included by service)
        $tasks = $subdivision['tasks'] ?? [];

        // Ensure tasks have assignees populated
        $taskModel = new \App\Models\TaskModel();
        foreach ($tasks as &$task) {
            if (!isset($task['assignees'])) {
                $task['assignees'] = $taskModel->getAssignees($task['id']);
            }
        }

        // Prepare status and priority labels
        $statusLabels = [
            'new' => 'Nou',
            'in_progress' => 'În progres',
            'blocked' => 'Blocat',
            'review' => 'În revizie',
            'completed' => 'Finalizat',
        ];

        $priorityLabels = [
            'low' => 'Scăzută',
            'medium' => 'Medie',
            'high' => 'Ridicată',
            'critical' => 'Critică',
        ];

        $statusBadgeClasses = [
            'new' => 'bg-subtle-gray',
            'in_progress' => 'bg-subtle-blue',
            'blocked' => 'bg-subtle-red',
            'review' => 'bg-subtle-yellow',
            'completed' => 'bg-subtle-green',
        ];

        $priorityBadgeClasses = [
            'low' => 'bg-subtle-green',
            'medium' => 'bg-subtle-yellow',
            'high' => 'bg-subtle-orange',
            'critical' => 'bg-subtle-red',
        ];

        $data = [
            'subdivision' => $subdivision,
            'tasks' => $tasks,
            'statusLabels' => $statusLabels,
            'priorityLabels' => $priorityLabels,
            'statusBadgeClasses' => $statusBadgeClasses,
            'priorityBadgeClasses' => $priorityBadgeClasses,
        ];

        return view('dashboard/subdivision', $data);
    }

    /**
     * Get chart data (AJAX endpoint for period filtering)
     * GET /dashboard/chart/tasks-region?period=30days
     */
    public function getChartData()
    {
        $session = service('session');
        $userId = $session->get('user_id');
        $role = $session->get('role');
        $regionId = $session->get('region_id');

        if (!$userId || !$role) {
            return $this->response->setJSON(['error' => 'Unauthorized'])->setStatusCode(401);
        }

        $period = $this->request->getGet('period') ?? '30days';
        $chartData = $this->dashboardService->getTasksPerRegionChart($userId, $role, $regionId, $period);

        return $this->response->setJSON($chartData);
    }

    /**
     * Send a test notification to the current user
     */
    protected function sendTestNotification(): void
    {
        $userId = session()->get('user_id');

        if (!$userId) {
            return;
        }

        $notificationService = new NotificationService();

        $notificationService->send(
            2,
            'info',
            'Notificare de Test',
            'Aceasta este o notificare de test. Dacă ești online, ai primit-o via Pusher. Dacă nu, ai primit-o pe email!',
            '/dashboard'
        );
    }

    /**
     * Send a test global notification
     */
    protected function testGlobalNotification(): void
    {
        $notificationService = new NotificationService();

        $notificationService->sendGlobal(
            'info',
            'Anunț Global',
            'Acesta este un anunț global pentru toți utilizatorii conectați.',
            '/dashboard'
        );
    }
}
