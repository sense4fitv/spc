<?= $this->include('partials/header') ?>

<main>
    <?= $this->renderSection('content') ?>
</main>

<?= $this->include('partials/footer') ?>